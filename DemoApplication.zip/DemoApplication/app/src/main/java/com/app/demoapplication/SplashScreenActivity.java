package com.app.demoapplication;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListPopupWindow;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.app.adapters.OptionsDropdownAdapter;
import com.app.models.ItemDataModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SplashScreenActivity extends Activity {

    private TextView txtTitle;
    private ImageButton btnOptions;
    private Activity activity;
    private Typeface typefaceRegular;
    private EditText etSearch;
    private TextWatcher textWatcherSearch;
    private String currentLanguageCode = "en";

    private PopupWindow popupSpecies;
    private OptionsDropdownAdapter myAdapter;
    private int lastSelectedItemPosition = 0;
    private int numberTypeWidth;
    private RelativeLayout rltLayoutParent;

    private ImagePagerAdapter mAdapter;
    private ViewPager mPager;
    ArrayList<ItemDataModel> itemsList = new ArrayList<>();

    private TextView txtProductName;
    private TextView txtPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        activity = this;
    }


    @Override
    protected void onResume() {
        super.onResume();
        initUI();
        setFonts();
        setListener();
        setCustomData();
    }

    private void initUI() {
        txtTitle = (TextView) findViewById(R.id.txt_title);
        txtTitle.setText(getResources().getString(R.string.products));
        btnOptions = (ImageButton) findViewById(R.id.btn_options);
        etSearch = (EditText) findViewById(R.id.et_search);
        typefaceRegular = Typeface.createFromAsset(activity.getApplicationContext().getAssets(), "RobotoCondensedRegular.ttf");

        txtProductName = (TextView) findViewById(R.id.txt_product_name);
        txtPrice = (TextView) findViewById(R.id.txt_price);

        rltLayoutParent = (RelativeLayout) findViewById(R.id.rlt_layout_main);
        rltLayoutParent.getViewTreeObserver()
                .addOnGlobalLayoutListener(new HomeLayoutListener());

        btnOptions.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                popupSpecies.setFocusable(true);

                if (popupSpecies != null) {
                    popupSpecies.showAsDropDown(btnOptions, 0, 0);
                }
                return true;
            }
        });

    }

    private void setCustomData() {

        for (int i = 1; i < 9; i++) {
            ItemDataModel itemDataModel = new ItemDataModel();
            itemDataModel.setItemName(getResources().getString(R.string.item) + " " + i);
            itemDataModel.setPrice(getResources().getString(R.string.price) + " : ₹" + i);
            if (i == 1) {
                itemDataModel.setImageResourceId(R.drawable.electronics_image1);
            } else if (i % 2 == 0) {
                itemDataModel.setImageResourceId(R.drawable.electronics_image2);
            } else if (i % 3 == 0) {
                itemDataModel.setImageResourceId(R.drawable.electronics_image3);
            } else {
                itemDataModel.setImageResourceId(R.drawable.electronics_image4);
            }
            itemsList.add(itemDataModel);
        }

        mAdapter = new ImagePagerAdapter(this);
        mPager = (ViewPager) findViewById(R.id.view_pager_products);
        mPager.setAdapter(mAdapter);
        mPager.setOnPageChangeListener(new IntroPageChangeListener());
        mPager.setCurrentItem(0);
    }

    private class IntroPageChangeListener implements ViewPager.OnPageChangeListener {

        @Override
        public void onPageScrollStateChanged(int arg0) {

        }

        @Override
        public void onPageScrolled(int arg0, float arg1, int arg2) {

        }

        @Override
        public void onPageSelected(int arg0) {
//            TODO
            txtProductName.setText(itemsList.get(arg0).getItemName());
            txtPrice.setText(itemsList.get(arg0).getPrice());
        }

    }


    public class ImagePagerAdapter extends PagerAdapter {
        Context context;

        ImagePagerAdapter(Context context) {
            this.context = context;
        }

        @Override
        public int getCount() {
            return itemsList.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == ((ImageView) object);
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            ImageView imageView = new ImageView(context);
            int padding = 0;
            imageView.setPadding(padding, padding, padding, padding);
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            imageView.setImageResource(itemsList.get(position).getImageResourceId());
            ((ViewPager) container).addView(imageView, 0);
            return imageView;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            ((ViewPager) container).removeView((ImageView) object);
        }

    }

    private void setFonts() {
        txtTitle.setTypeface(typefaceRegular);
        etSearch.setTypeface(typefaceRegular);
    }

    private void setListener() {

        textWatcherSearch = new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (s.toString().contains("1")) {
                    mPager.setCurrentItem(0);
                } else if (s.toString().contains("2")) {
                    mPager.setCurrentItem(1);
                } else if (s.toString().contains("3")) {
                    mPager.setCurrentItem(2);
                } else if (s.toString().contains("4")) {
                    mPager.setCurrentItem(3);
                } else if (s.toString().contains("5")) {
                    mPager.setCurrentItem(4);
                } else if (s.toString().contains("6")) {
                    mPager.setCurrentItem(5);
                } else if (s.toString().contains("7")) {
                    mPager.setCurrentItem(6);
                } else if (s.toString().contains("8")) {
                    mPager.setCurrentItem(7);
                }

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        };

        etSearch.addTextChangedListener(textWatcherSearch);
    }

    private void switchLanguage(String languageSelected) {
        Locale locale = new Locale(languageSelected);
        Configuration config = new Configuration();
        config.locale = locale;
        activity.getApplicationContext().getResources().updateConfiguration(config, null);
        onResume();
    }

    private class HomeLayoutListener implements ViewTreeObserver.OnGlobalLayoutListener {
        @Override
        public void onGlobalLayout() {

            numberTypeWidth = btnOptions.getWidth();

            numberTypeWidth = 300;

            popupSpecies = popupSpecies();

        }
    }

    private PopupWindow popupSpecies() {

        final PopupWindow popupWindow = new PopupWindow(activity);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setTouchable(true);
        popupWindow.setFocusable(true);

        ListView listViewLanguage = new ListView(activity);

        final List<String> listOptions = new ArrayList<String>();

        listOptions.add("English");
        listOptions.add("Portuguese");

        myAdapter = new OptionsDropdownAdapter(activity, listOptions, lastSelectedItemPosition);

        listViewLanguage.setAdapter(myAdapter);

        listViewLanguage.setSelection(lastSelectedItemPosition);

        listViewLanguage.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View v, int position,
                                    long arg3) {
                Animation fadeInAnimation = AnimationUtils.loadAnimation(
                        v.getContext(), android.R.anim.fade_in);
                fadeInAnimation.setDuration(10);
                v.startAnimation(fadeInAnimation);

                if (listOptions.get(position).toString().trim().equalsIgnoreCase("English")) {
                    currentLanguageCode = "en";
                } else {
                    currentLanguageCode = "pt";
                }

                //            TODO Switch language as per selection
                switchLanguage(currentLanguageCode);
                if (currentLanguageCode.equalsIgnoreCase("en")) {
                    Toast.makeText(activity, getResources().getString(R.string.language_changed_to_english), Toast.LENGTH_LONG).show();
                    etSearch.setHint("Search Products");
                } else {
                    Toast.makeText(activity, getResources().getString(R.string.language_changed_to_portuguese), Toast.LENGTH_LONG).show();
                    etSearch.setHint("Procurar produtos");
                }

                lastSelectedItemPosition = position;

                popupWindow.dismiss();

            }
        });

        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {

            }
        });

        popupWindow.setWidth(numberTypeWidth);
        popupWindow.setHeight(WindowManager.LayoutParams.WRAP_CONTENT);

        btnOptions.setFocusable(true);
        btnOptions.setFocusableInTouchMode(true);

        popupWindow.setContentView(listViewLanguage);

        popupWindow
                .setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        return popupWindow;
    }

    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
    }

    // To Hide Keyboard on outside Touch
    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        View view = getCurrentFocus();
        boolean ret = super.dispatchTouchEvent(event);

        if (view instanceof EditText) {
            View w = getCurrentFocus();
            int scrcoords[] = new int[2];
            w.getLocationOnScreen(scrcoords);
            float x = event.getRawX() + w.getLeft() - scrcoords[0];
            float y = event.getRawY() + w.getTop() - scrcoords[1];

            if (event.getAction() == MotionEvent.ACTION_UP && (x < w.getLeft() || x >= w.getRight() || y < w.getTop() || y > w.getBottom())) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(getWindow().getCurrentFocus().getWindowToken(), 0);
            }
        }
        return ret;
    }


}
